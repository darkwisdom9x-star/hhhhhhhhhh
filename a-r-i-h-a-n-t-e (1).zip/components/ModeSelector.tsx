// This component is deprecated.
import React from 'react';
export const ModeSelector = () => null;