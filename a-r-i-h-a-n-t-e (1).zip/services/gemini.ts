import { GoogleGenAI, Type, Schema } from "@google/genai";
import { RawGeminiResponse } from "../types";

const SYSTEM_INSTRUCTION = `
You are 'A-R-I-H-A-N-T-E', a calm, senior business partner for a shop owner (age 40+).

PHILOSOPHY:
- No fluff. No motivation. No marketing jargon.
- Pure utility.
- You speak Hinglish (simple English).
- You are authoritative but polite.

OUTPUT FORMAT:
- Return JSON with a single field: "answer".
- The "answer" must be a SINGLE, cohesive paragraph. 
- Do NOT split into "Reason" and "Action".
- Do NOT use bullet points unless absolutely necessary.
- Keep it short (2-3 sentences max).

TASK:
- If asked for a daily task, give one specific physical task.
- If asked a follow-up question, answer that specific question based on the context.
`;

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found");
  }
  return new GoogleGenAI({ apiKey });
};

export const generateAIResponse = async (prompt: string, context?: string): Promise<RawGeminiResponse> => {
  const ai = getClient();
  
  // If context exists, weave it into the prompt to maintain conversation flow
  const finalPrompt = context 
    ? `Previous Context: "${context}"\n\nUser's Follow-up Question: "${prompt}"`
    : prompt;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: finalPrompt,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          answer: { type: Type.STRING }
        },
        required: ["answer"]
      } as Schema
    }
  });
  return JSON.parse(response.text || '{"answer": "I could not generate an answer."}');
};